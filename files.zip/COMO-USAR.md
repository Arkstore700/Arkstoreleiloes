# Login real com Discord — guia completo

Esses 4 arquivos fazem a parte de servidor do login com Discord (o que um
site estático sozinho não consegue fazer). Siga os passos na ordem.

## 1. Criar o app no Discord

1. Acesse https://discord.com/developers/applications
2. Clique em **New Application**, dê um nome (ex: `ARK Leilões`)
3. Vá em **OAuth2 → General**
4. Copie o **Client ID**
5. Clique em **Reset Secret** e copie o **Client Secret** (aparece só uma vez — guarde bem)

## 2. Montar a pasta do projeto

```
ark-leiloes/
├── index.html          <- o site (o HTML que já te entreguei)
└── api/
    ├── discord-login.js
    ├── discord-callback.js
    ├── me.js
    └── logout.js
```

Baixe os 4 arquivos `.js` e coloque dentro de uma pasta chamada `api`, no
mesmo nível do `index.html`.

## 3. Subir para o GitHub

1. Crie uma conta em https://github.com (se ainda não tiver)
2. Crie um repositório novo (pode ser privado)
3. Suba a pasta inteira (dá pra arrastar os arquivos direto pela interface
   do GitHub, sem precisar usar terminal)

## 4. Publicar no Vercel

1. Crie uma conta em https://vercel.com fazendo login "with GitHub"
2. Clique em **Add New → Project**
3. Escolha o repositório que você acabou de subir
4. Clique em **Deploy** (não precisa mexer em nenhuma configuração aqui)

O Vercel detecta a pasta `api/` sozinho e transforma cada arquivo num
"endpoint" de servidor — é o mesmo esquema que o site que você usou como
referência (marshow-leilao) usa.

## 5. Configurar as variáveis de ambiente

No painel do projeto no Vercel: **Settings → Environment Variables**.
Adicione estas 4:

| Nome                     | Valor                                                   |
|--------------------------|----------------------------------------------------------|
| `DISCORD_CLIENT_ID`      | o Client ID que você copiou no passo 1                  |
| `DISCORD_CLIENT_SECRET`  | o Client Secret que você copiou no passo 1              |
| `DISCORD_REDIRECT_URI`   | `https://SEU-PROJETO.vercel.app/api/discord-callback`   |
| `SESSION_SECRET`         | qualquer texto longo e aleatório (ex: gere uma senha forte) |

Depois de salvar, vá em **Deployments** e clique em **Redeploy** pra essas
variáveis entrarem em vigor.

## 6. Cadastrar o Redirect URI no Discord

Volte no [Discord Developer Portal](https://discord.com/developers/applications) →
seu app → **OAuth2 → General → Redirects → Add Redirect**, e cole
exatamente a mesma URL que você colocou em `DISCORD_REDIRECT_URI` acima.
Salve.

## 7. Ligar o botão do site a essas rotas

No `index.html`, troque o comportamento do botão "Entrar" pra apontar
direto pra rota de login, em vez de abrir o formulário com senha:

```html
<a href="/api/discord-login" class="btn-primary" style="text-decoration:none;display:inline-block;">
  Entrar com Discord
</a>
```

E, ao carregar a página, pergunte quem está logado:

```html
<script>
fetch("/api/me")
  .then(r => r.json())
  .then(data => {
    if (data.loggedIn) {
      // data.user.username e data.user.avatar já vêm prontos do Discord
      console.log("Logado como:", data.user.username);
      // aqui você atualiza o cabeçalho do site com o nome/avatar
    }
  });
</script>
```

E o botão de sair aponta pra `/api/logout`.

## 8. Testar

Acesse `https://SEU-PROJETO.vercel.app`, clique em entrar — deve te levar
pro Discord, pedir autorização, e trazer você de volta já logado.

---

## O que esse login NÃO resolve sozinho

O login com Discord só te dá o **nome de usuário e avatar do Discord**.
Ele não sabe qual é o seu nick do Minecraft, nem guarda os leilões/lances
em um lugar compartilhado entre todo mundo — isso precisa de um banco de
dados de verdade (ex: Vercel KV, Supabase, Firebase). Esse é o próximo
passo natural depois que o login estiver funcionando: aí sim os leilões,
lances e banimentos passam a ser vistos por todo mundo, não só salvos no
navegador de cada pessoa.

Se quiser, no próximo passo eu te ajudo a montar esse banco de dados
também.
